﻿using System;
using Castle.Facilities.TypedFactory;
using Castle.MicroKernel.Registration;
using Castle.Windsor;

namespace Test_Castle_Windsor_dispose_out_of_order
{
    class Program
    {
        static void Main()
        {
            using (var container = new WindsorContainer())
            {
                container.AddFacility<TypedFactoryFacility>();
                container.Register(Component.For<InnerDependency>());
                container.Register(Component.For<OuterService>());


                var outerService = container.Resolve<OuterService>();
                try
                {
                    outerService.Test();
                }
                finally
                {
                    container.Release(outerService);
                }
            }
        }
    }

    public sealed class InnerDependency 
    {
    }

    public sealed class OuterService : IDisposable
    {
        private readonly Func<InnerDependency> dependencyFactory;

        public OuterService(Func<InnerDependency> dependencyFactory)
        {
            this.dependencyFactory = dependencyFactory;
        }

        public void Test()
        {
            dependencyFactory.Invoke();
        }

        public void Dispose()
        {
            Test();
        }
    }
}
