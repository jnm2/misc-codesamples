﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace NCrunch_NUnit_TestCaseData_bug
{
    [TestFixture]
    public class TestCaseSourceExample
    {
        public static IEnumerable<TestCaseData> ExampleTestCaseGenerator()
        {
            var start = DateTime.UtcNow.Second; // What changes in my case is external to the code

            /* To see the problem:
               
             1. Run all the tests initially. Each one will be correct.

             2. Open the NCrunch Tests window and show both passing and failed tests.
                You should see all the odd tests fail, from the current number of seconds on the system clock to 59.
                Each test reports the parameter it was given. (In NCrunch you can only see messages from the failing tests, though.)

             3. Without changing any code, right click and rerun individual tests, both passing and failing.
                Because the tests at the beginning are steadily disappearing, the reported parameter will not match the test name.
                Also, there is a 50-50 chance that the first test will no longer have the same parity as when the test you are running was last run,
                so half the time, tests with even numbers in the name will fail saying they are odd and tests with odd numbers in the name will pass.
            */

            return Enumerable.Range(start, 59 - start).Select(_ => new TestCaseData(_));
        }

        [TestCaseSource(nameof(ExampleTestCaseGenerator))]
        public void ParameterMustBeEven(int parameter)
        {
            if (parameter % 2 == 0)
                Assert.Pass($"{parameter} is even.");
            else
                Assert.Fail($"{parameter} is odd.");
        }
    }
}
