﻿using System;

namespace ClassLibrary
{
    public sealed class TestAttribute : Attribute
    {
    }
}
