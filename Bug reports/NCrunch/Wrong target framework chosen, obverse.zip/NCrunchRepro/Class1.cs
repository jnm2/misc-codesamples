using ClassLibrary;

namespace NCrunchRepro
{
    [Test]
    public sealed class Class1
    {
    }
}
