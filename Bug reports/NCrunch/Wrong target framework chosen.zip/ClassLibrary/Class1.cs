#if !NETSTANDARD1_6
namespace ClassLibrary
{
    public class Class1
    {
    }
}
#endif
