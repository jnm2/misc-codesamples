#if !NETCOREAPP1_1
namespace NCrunchRepro
{
    class Class1 : ClassLibrary.Class1
    {
    }
}
#endif
