﻿using System;

namespace Techsola.HeritagePMS.Client
{
    static class Program
    {
        [STAThread]
        public static void Main()
        {
        }
    }
}