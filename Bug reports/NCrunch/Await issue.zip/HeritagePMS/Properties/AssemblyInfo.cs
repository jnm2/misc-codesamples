﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Heritage Poultry Management Services, Inc.")]
[assembly: AssemblyDescription("Heritage Poultry Management Services, Inc.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Technology Solutions Associates")]
[assembly: AssemblyProduct("Heritage Poultry Management Services, Inc.")]
[assembly: AssemblyCopyright("Copyright © 2013 Technology Solutions Associates")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("279739db-98d7-4571-b5b5-7b99668523c8")]
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Value
//      Revision
//
[assembly: AssemblyVersion("1.4.5.0")]
[assembly: AssemblyFileVersion("1.4.5.0")]

[assembly: InternalsVisibleTo("HeritagePMS.Test, PublicKey=00240000048000009400000006020000002400005253413100040000010001005d899432ded5e989354c2ddf2c85cc4ac383102701a2507d313f02e3d46fc61cdc08626cdce14f8440f8275ce6bed56f806406b72aabd2cd37299c5dd17a3b4a3dfd7b09c06cdff9c347e00a89ce3e057ef18787bbca3635e063ac8edd9a0f1748fefa01967973c3dc0111ea2545c7d4dd125c8bc8c87977bddfbd83f07d53a5")]