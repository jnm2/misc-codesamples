﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

#pragma warning disable 4014

[TestClass]
class TestAwaitFailure
{
    // These test times out randomly. It seems to time out most frequently when I'm typing an another project in the solution and NCrunch builds projects and runs tests in the background.
    // (To repro: type a space in the main project's Program.cs and undo it. The build should start and this test should fail every time.)
    // Doesn't tend to happen when I run it directly.
    [TestMethod]
    public async Task TaskCompletionSourceAsync()
    {
        var tcs = new TaskCompletionSource<object>();
        Task.FromResult<object>(null).ContinueWith(_ => tcs.SetResult(null));
        await tcs.Task;
    }

    // This times out in a bigger project but not in the small project:

    [TestMethod]
    public async Task DelayAsync()
    {
        await Task.Delay(10);
    }
    
    // These tests do not time out:
        
    [TestMethod]
    public Task TaskCompletionSource()
    {
        for (var i = 0; i < 100; i++)
            Task.Run(() => Thread.Sleep(10000));

        var tcs = new TaskCompletionSource<object>();
        Task.FromResult<object>(null).ContinueWith(_ => tcs.SetResult(null));
        return tcs.Task;
    }

    [TestMethod]
    public async Task AwaitTaskCompletionSourceImmediate()
    {
        for (var i = 0; i < 100; i++)
            Task.Run(() => Thread.Sleep(10000));

        var tcs = new TaskCompletionSource<object>();
        tcs.SetResult(null);
        await tcs.Task;
    }

    [TestMethod]
    public Task Delay()
    {
        for (var i = 0; i < 100; i++)
            Task.Run(() => Thread.Sleep(10000));

        return Task.Delay(10);
    }
}