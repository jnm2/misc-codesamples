﻿using NUnit.Framework;

namespace NonGuiTestProject
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void TestMethod1()
        {
        }
    }
}