﻿using System;
using System.ComponentModel;

namespace NetstandardLibrary
{
    public static class Class1
    {
        public static void Works()
        {
            throw new Win32Exception();
        }
    }
}
