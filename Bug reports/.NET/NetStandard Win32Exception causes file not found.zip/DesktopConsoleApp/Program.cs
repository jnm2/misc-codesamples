﻿using NetstandardLibrary;

namespace DesktopConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1.Works();
        }
    }
}
