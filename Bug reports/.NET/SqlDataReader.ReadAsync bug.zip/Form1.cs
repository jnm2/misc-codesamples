﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SqlDataReader.ReadAsync_bug
{
    public partial class Form1 : Form
    {
        private const string ConnectionString = @"Your connection string";
        private static readonly List<Exception> ObservedExceptions = new List<Exception>();

        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Shown(object sender, EventArgs e)
        {
            TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;

            using (var connection = new SqlConnection(ConnectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand("select 1 / x from (values (1), (0)) v (x)", connection))
                {
                    try
                    {
                        using (var reader = await command.ExecuteReaderAsync())
                            while (await reader.ReadAsync())// ReadAsync will fail and exhibit the bug
                            {
                            }
                    }
                    catch (SqlException ex)
                    {
                        ObservedExceptions.Add(ex);
                        Debugger.Break(); // This exception is definitely observed by the await and caught.
                    }
                }
            }

            GC.Collect(); // Simulate loading a new window with enough data to cause a GC.
        }

        private static void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            if (ObservedExceptions.Contains(e.Exception.InnerException))
                throw new Exception("This exception was already observed by awaiting."); // So you should never end up here.
        }
    }
}
