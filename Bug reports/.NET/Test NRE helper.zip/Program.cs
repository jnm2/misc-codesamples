﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_NRE_helper
{
    class Program
    {
        static void Main(string[] args)
        {
            var x = (object)1;
            (x as string).Trim();
        }
    }
}
