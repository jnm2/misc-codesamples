﻿namespace ConsoleAppWithSettings
{
    public static class Program
    {
        public static void Main()
        {
        }
    }
}