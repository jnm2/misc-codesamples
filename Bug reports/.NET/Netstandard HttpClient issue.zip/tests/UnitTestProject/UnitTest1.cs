﻿using System.Threading.Tasks;
using NUnit.Framework;
using ClassLibrary;

namespace UnitTestProject
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public Task TestMethod1()
        {
            return Class1.Run();
        }
    }
}
