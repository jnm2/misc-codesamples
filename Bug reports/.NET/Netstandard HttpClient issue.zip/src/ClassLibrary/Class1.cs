﻿using System.Net.Http;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Class1
    {
        public static Task Run()
        {
            return new HttpClient().GetAsync("http://www.google.com");
        }
    }
}
